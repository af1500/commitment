
import 'dotenv/config';

export default {
  expo: {
    name: "AI Fitness Coach",
    slug: "ai-fitness-coach",
    version: "1.0.0",
    extra: {
      firebaseApiKey: process.env.EXPO_FIREBASE_API_KEY || "YOUR_FIREBASE_API_KEY_HERE",
      firebaseAuthDomain: process.env.EXPO_FIREBASE_AUTH_DOMAIN || "YOUR_FIREBASE_AUTH_DOMAIN",
      firebaseProjectId: process.env.EXPO_FIREBASE_PROJECT_ID || "YOUR_FIREBASE_PROJECT_ID",
      firebaseStorageBucket: process.env.EXPO_FIREBASE_STORAGE_BUCKET || "YOUR_FIREBASE_STORAGE_BUCKET",
      firebaseMessagingSenderId: process.env.EXPO_FIREBASE_MESSAGING_SENDER_ID || "YOUR_FIREBASE_MESSAGING_SENDER_ID",
      firebaseAppId: process.env.EXPO_FIREBASE_APP_ID || "YOUR_FIREBASE_APP_ID",
      backendUrl: process.env.EXPO_BACKEND_URL || "http://localhost:4000"
    }
  }
};
