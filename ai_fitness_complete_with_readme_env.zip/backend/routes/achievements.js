// Achievements route implementation
