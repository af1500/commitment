// User sync route implementation
