// Seasons route implementation
