
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';

import AuthScreen from './src/screens/AuthScreen';
import AICoach from './src/screens/AICoach';
import StatsScreen from './src/screens/StatsScreen';
import AchievementsScreen from './src/screens/AchievementsScreen';
import ChallengesScreen from './src/screens/ChallengesScreen';
import SeasonsScreen from './src/screens/SeasonsScreen';
import PaymentScreen from './src/screens/PaymentScreen';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          headerShown: false,
          tabBarIcon: ({ color, size }) => {
            let iconName;
            switch (route.name) {
              case 'Auth': iconName = 'log-in-outline'; break;
              case 'AI Coach': iconName = 'chatbubble-ellipses-outline'; break;
              case 'Stats': iconName = 'stats-chart-outline'; break;
              case 'Achievements': iconName = 'trophy-outline'; break;
              case 'Challenges': iconName = 'flag-outline'; break;
              case 'Seasons': iconName = 'time-outline'; break;
              case 'Payment': iconName = 'card-outline'; break;
              default: iconName = 'apps-outline';
            }
            return <Ionicons name={iconName} size={size} color={color} />;
          }
        })}
      >
        <Tab.Screen name="Auth" component={AuthScreen} />
        <Tab.Screen name="AI Coach" component={AICoach} />
        <Tab.Screen name="Stats" component={StatsScreen} />
        <Tab.Screen name="Achievements" component={AchievementsScreen} />
        <Tab.Screen name="Challenges" component={ChallengesScreen} />
        <Tab.Screen name="Seasons" component={SeasonsScreen} />
        <Tab.Screen name="Payment" component={PaymentScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
