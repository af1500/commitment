# AI Fitness App

This project contains a full-stack AI-powered fitness coach app.

## Structure

- `frontend/`: Expo React Native mobile app
- `backend/`: Express + Node.js API server
- `backend/db/`: Postgres schema and seeds
- `scripts/`: helper scripts
- `.github/workflows/ci.yml`: GitHub Actions CI pipeline

## Setup Instructions

### Requirements
- Node.js >= 18
- npm or yarn
- Expo CLI (`npm install -g expo-cli`)
- Docker (for running Postgres easily)
- PostgreSQL client (psql)

### Backend

1. Copy `.env.example` to `.env` in `backend/` and fill in your keys:
   ```env
   DATABASE_URL=postgres://postgres:postgres@localhost:5432/aifitness
   GEMINI_URL=https://api.gemini-provider.com/chat
   GEMINI_KEY=YOUR_GEMINI_KEY
   BRAINTREE_KEY=YOUR_BRAINTREE_KEY
   FIREBASE_PROJECT_ID=YOUR_FIREBASE_PROJECT_ID
   ```

2. Start Postgres (with Docker):
   ```bash
   docker-compose up -d db
   ```

3. Initialize DB:
   ```bash
   psql -h localhost -U postgres -d aifitness -f backend/db/schema.sql
   psql -h localhost -U postgres -d aifitness -f backend/db/seeds.sql
   ```

4. Start backend server:
   ```bash
   cd backend
   npm install
   npm run dev
   ```

   Server will run on `http://localhost:4000`.

### Frontend

1. Install dependencies:
   ```bash
   cd frontend
   npm install
   ```

2. Start Expo:
   ```bash
   npm start
   ```

3. Use Expo Go app on your device or an emulator to test.

### Testing

```bash
cd backend
npm test
```

### CI

This repo contains a GitHub Actions workflow in `.github/workflows/ci.yml` that runs tests on each push.

## Notes

- All API keys and credentials are left as placeholders. Replace with your actual Firebase, Gemini, Mailchimp, and Braintree keys.
- The AI route includes retry and fallback logic.
- Payment integration requires Braintree server-side setup.
