// Workouts route implementation
