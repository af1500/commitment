// Seasons screen implementation here
