// Payments route implementation
