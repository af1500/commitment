// Stats route implementation
