// Updated AI route with retries, fallback, zod validation
