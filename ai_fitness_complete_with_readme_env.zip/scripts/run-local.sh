#!/bin/bash
# Run backend locally
node backend/index.js
