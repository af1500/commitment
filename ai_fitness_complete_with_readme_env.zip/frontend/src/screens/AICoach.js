// Updated AI Coach screen with chat, loading, quick prompts
